# Istanbul Real Estate 2024 — Anonymized (Celik Gayrimenkul)

Synthetic-anonymized dataset derived from Celik Gayrimenkul's production schema (Property model: `server/prisma/schema.prisma:210`), with PII removed and values synthesized for Kaggle.

**Rows:** 8000 | **Source:** `celik-gayrimenkul` open-source real-estate platform (Istanbul-focused)
**License:** CC BY 4.0 | **Update:** 2024-09

## Columns
- `property_id` — anonymized ID (PROP_00000…)
- `city`, `district` — location (8 cities, 31 districts, Istanbul 45%)
- `property_type` — RESIDENTIAL/COMMERCIAL/LAND/INDUSTRIAL
- `listing_type` — SALE (65%) / RENT (35%)
- `area_sqm` — living area (30–709, mean 151)
- `price_try` — price in TRY (SALE) or monthly rent (RENT); base per sqm by city (Istanbul 18k, Ankara 12k…)
- `currency` — TRY
- `bedrooms`, `bathrooms`, `year_built` — residential only
- `has_elevator`, `has_parking`, `has_balcony` — boolean
- `ai_score` — 0.4–0.95 synthetic AI valuation confidence
- `view_count` — Poisson(120)

## Use cases
- Price prediction (regression) — predict `price_try` from location + area + type
- Classification — RENT vs SALE, or `ai_score` bucket
- EDA — Istanbul premium vs Ankara, area/price correlation, district hotspots

## Generation
Python `numpy` synthetic, seed 42, distributions calibrated to Turkish market 2024 (base price per sqm by city, age depreciation 0.5%/year, etc). No real user data included. See `generate.py` for seed.

## Citation
If you use this dataset, please cite: `Celik Gayrimenkul — github.com/anomalyco/celik-gayrimenkul`

